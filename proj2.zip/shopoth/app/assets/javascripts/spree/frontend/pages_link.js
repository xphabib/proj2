Spree.fetchPagesLink = function () {
    return $.ajax({
        url: Spree.pathFor('static_pages_link')
    }).done(function (data) {
        Spree.pagesLinkFetched = true
        return $('#static-pages-menu').html(data)
    })
}

Spree.ready(function () {
    if (!Spree.pagesLinkFetched) Spree.fetchPagesLink()
})
