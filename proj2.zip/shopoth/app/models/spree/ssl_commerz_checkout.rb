module Spree
  class SslCommerzCheckout < ApplicationRecord
    # scope :in_state, ->(state) { where(state: state) }
    # scope :not_in_state, ->(state) { where.not(state: state) }

    # after_commit :update_payment_and_order

    # FINAL_STATES = %w(authorization_expired processor_declined gateway_rejected failed voided settled settlement_declined refunded released).freeze

    has_one :payment, foreign_key: :source_id, as: :source, class_name: 'Spree::Payment'
    has_one :order, through: :payment

    private

    # def update_payment_and_order
    #   return unless (changes = previous_changes[:state])
    #   return unless changes[0] != changes[1]
    #   return unless payment
    #   payment.send(payment_action(payment_state))
    # end

    # def payment_action(state)
    #   case state
    #   when 'pending'
    #     'pend'
    #   when 'void'
    #     'void'
    #   when 'completed'
    #     'complete'
    #   else
    #     'failure'
    #   end
    # end
  end
end