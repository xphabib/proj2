module Spree
  def self.table_name_prefix
    'spree_'
  end
end
