module Spree::Admin::SearchHistoriesHelper
end