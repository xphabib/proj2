module Spree
  module Admin
    class SearchHistoriesController < ResourceController
      def index
        searched_products = Spree::SearchHistory.all.order(no_of_search: :desc)
        @searched_products = searched_products.page(params[:page]).per(params[:per_page].present? ? params[:per_page] : 20)
      end
    end
  end
end

