module Spree
  module CheckoutControllerDecorator
    def self.prepended(base)
      # base.after_action :update_source_data, only: :update, if: proc { params[:state].eql?('payment') }
      base.skip_before_action :verify_authenticity_token, only: [:payment_success]
    end

    def update
      if paying_with_ssl_commerz?
        _response = @payment_method.purchase(@order)
        redirect_to _response['redirectGatewayURL']
      else
        super
      end
    end

    # This action is for SSL Commerz payment success callback url
    def payment_success
      order = current_order
      attributes = %w(tran_id val_id amount card_type store_amount card_no bank_tran_id status tran_date \
error currency card_issuer card_brand card_sub_brand card_issuer_country card_issuer_country_code store_id verify_sign \
verify_key verify_sign_sha2 currency_type currency_amount currency_rate base_fair value_a value_b value_c value_d risk_level risk_title)
      permitted_attributes = params.permit(attributes)

      payment = order.payments.create!({
                                           :source => Spree::SslCommerzCheckout.create(permitted_attributes),
                                           :amount => order.total,
                                           :payment_method => payment_method,
                                           :response_code => permitted_attributes['val_id'],
                                       })

      payment.pend
      if permitted_attributes['status'] == 'VALID'
        # Set payment to completed after order.next because
        # spree expects at least one incomplete payment to process an order to complete
        order.next!
        payment.complete
        # This is a hack - for some reason the payment_state and shipment_state weren't being persisted
        # and where being stored in the database as null. Really the spree checkout process
        # should take care of this and we shouldn't have to set them manually.
        # We must be doing something wrong...
        #
        order.update_attributes({ payment_state: 'paid', shipment_state: 'ready', completed_at: DateTime.now.utc })
        # order.finalize!

        flash.notice = Spree.t(:payment_processed_successfully)
        session[:order_id] = nil
        redirect_to completion_route(order)
      else
        payment.failure
        flash.notice = Spree.t(:payment_error)
        flash.notice = "Payment error status: #{permitted_attributes['status']}, error message: #{permitted_attributes['error']}"
        redirect_to checkout_state_path(order.state)
      end

      # if order.complete?
      #   # flash.notice = Spree.t(:order_processed_successfully)
      #   flash.notice = Spree.t(:payment_processed_successfully)
      #   session[:order_id] = nil
      #   redirect_to completion_route(order)
      # else
      #   flash.notice = 'Error: ' + 'NOT SUCCESS' + '. Please try again.'
      #   redirect_to checkout_state_path(order.state)
      # end
    end

    private

    def payment_method
      if params[:order].present? && params[:order][:payments_attributes].present?
        permitted_params = params[:order] ? params[:order].permit(permitted_checkout_attributes).delete_if { |_k, v| v.nil? } : {}
        payment_method_id = permitted_params[:payments_attributes].first[:payment_method_id]
      elsif params[:value_b].present?
        payment_method_id = params[:value_b]
      end
      @payment_method ||= Spree::PaymentMethod.find(payment_method_id)
    end

    def paying_with_ssl_commerz?
      # payment_method = PaymentMethod.find(payment_method.id)
      # binding.pry
      params[:order][:payments_attributes].present? && payment_method.is_a?(Spree::Gateway::SslCommerz)
    end

    def check_registration
      return unless Spree::Auth::Config[:registration_step]
      return if spree_current_user || current_order.email
      store_location
      redirect_to spree.checkout_registration_path
    end

    # def update_source_data
    #   return true unless current_order
    #   payment = current_order.payments.last
    #   return true unless payment
    #   source = payment.source
    #   return true unless source.is_a?(Spree::BraintreeCheckout)
    #   update_advanced_fraud_data(source)
    # end

    def update_advanced_fraud_data(source)
      source.update(advanced_fraud_data: params[:device_data])
    end
  end
end

::Spree::CheckoutController.prepend(Spree::CheckoutControllerDecorator)