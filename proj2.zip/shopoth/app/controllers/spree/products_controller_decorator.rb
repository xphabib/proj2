Spree::ProductsController.class_eval do
  before_action :store_search_data, only: [:index]

  private
  def store_search_data
    return false unless params[:keywords].present?
    search_data = Spree::SearchHistory.find_or_create_by(title: params[:keywords].downcase)
    search_data.update(no_of_search: search_data.no_of_search + 1)
  end
end
