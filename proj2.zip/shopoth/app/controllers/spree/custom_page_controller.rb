module Spree
  class CustomPageController < StoreController
    def get_pages
      pages = Spree::Page.all
      render partial: 'spree/shared/page_links', locals: { pages: pages }
    end
  end
end
