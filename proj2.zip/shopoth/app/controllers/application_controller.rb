class ApplicationController < ActionController::Base

  # stop google indexing on staging
  if Rails.env.staging?
    http_basic_authenticate_with(
        name: APPLICATION_CONFIG['site_username'],
        password: APPLICATION_CONFIG['site_password']
    )
  end
end
