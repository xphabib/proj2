require 'test_helper'

class Spree::SslCommerzCheckoutTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
