require 'test_helper'

class Spree::SearchHistoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
