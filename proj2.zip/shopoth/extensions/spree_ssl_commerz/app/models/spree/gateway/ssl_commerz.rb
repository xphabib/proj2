module Spree
  class Gateway::SslCommerz < Gateway
    preference :store_key, :string
    preference :store_password, :string

    GATEWAY_API_URL = {
        sandbox: ENV['SSL_COMMERZ_SANDBOX_API_URL'],
        live: ENV['SSL_COMMERZ_LIVE_API_URL']
    }

    def source_required?
      false
    end

    def auto_capture?
      true
    end

    def method_type
      'ssl_commerz'
    end

    def provider_class
      self.class
    end

    def payment_profiles_supported?
      false
    end

    def purchase(order)
      # provider.purchase(*options_for_purchase_or_auth(money, credit_card, gateway_options))
      initiate_payment(order)
    end

    def authorize(money, credit_card, gateway_options)
      # provider.authorize(*options_for_purchase_or_auth(money, credit_card, gateway_options))
    end

    def capture(money, response_code, gateway_options)
      provider.capture(money, response_code, gateway_options)
    end

    def credit(money, credit_card, response_code, gateway_options)
      provider.refund(money, response_code, {})
    end

    def void(response_code, credit_card, gateway_options)
      # provider.void(response_code, {})
    end

    def cancel(response_code)
      # provider.void(response_code, {})
    end

    private

    def initiate_payment(order)
      url = (Rails.env.production? ? GATEWAY_API_URL[:live] : GATEWAY_API_URL[:sandbox]) + '/gwprocess/v4/api.php'
      app_base = ''
      if Rails.env.development?
        app_base = 'http://localhost:3000'
      elsif Rails.env.staging?
        app_base = 'http://shopoth.net'
      else
      end

      params = {
          "store_id" => preferences[:store_key],
          "store_passwd" => preferences[:store_password],
          "total_amount" => order.total.to_f,
          "currency" => "BDT",
          "tran_id" => order.number,
          "success_url" => "#{app_base}/checkout/payment/success",
          "fail_url" => "#{app_base}/checkout/payment/fail",
          "cancel_url" => "#{app_base}/checkout/payment/cancel",

          "cus_name" => order.bill_address&.full_name,
          "cus_email" => order&.email,
          "cus_add1" => order.bill_address&.address1,
          "cus_add2" => order.bill_address&.address2,
          "cus_city" => order.bill_address&.city,
          "cus_state" => order.bill_address&.state,
          "cus_postcode" => order.bill_address&.zipcode,
          "cus_country" => order.bill_address&.country,
          "cus_phone" => order.bill_address&.phone,

          "shipping_method" => 'YES',
          "ship_name" => order.ship_address&.full_name,
          "ship_add1" => order.ship_address&.address1,
          "ship_add2" => order.ship_address&.address2,
          "ship_city" => order.ship_address&.city,
          "ship_state" => order.ship_address&.state,
          "ship_postcode" => order.ship_address&.zipcode,
          "ship_country" => order.ship_address&.country,
          "product_name" => order&.products&.collect{|x| x.name}.join(','),
          "product_category" => order.products.inject([]){|a, b| a << b.category.name}.join(','),
          "product_profile" => 'general',

          "value_a" => order.id,
          "value_b" => self.id,
      }

      # binding.pry
      uri = URI(url)
      res = Net::HTTP.post_form(uri, params)
      puts JSON.parse res.body
      JSON.parse res.body
    end

    # def update_source!(source)
    #   source.cc_type = CARD_TYPE_MAPPING[source.cc_type] if CARD_TYPE_MAPPING.include?(source.cc_type)
    #   source
    # end

  end
end