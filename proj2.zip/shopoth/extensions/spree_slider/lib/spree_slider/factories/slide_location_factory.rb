FactoryBot.define do
  factory :slide_location, class: Spree::SlideLocation do
    name { 'Home' }
  end
end
