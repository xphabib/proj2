class Spree::SliderConfig < ActiveRecord::Base

end