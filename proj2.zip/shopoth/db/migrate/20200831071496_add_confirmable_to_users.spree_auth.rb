# This migration comes from spree_auth (originally 20141002154641)
class AddConfirmableToUsers < SpreeExtension::Migration[4.2]
  def change
    add_column :spree_users, :confirmation_token, :string
    add_column :spree_users, :confirmed_at, :datetime
    add_column :spree_users, :confirmation_sent_at, :datetime
  end
end
