# This migration comes from spree_slider (originally 20201005044821)
class CreateSliderConfig < ActiveRecord::Migration[6.0]
  def change
    create_table :spree_slider_configs do |t|
      t.integer :interval
      t.timestamps
    end
  end
end
