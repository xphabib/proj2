class CreateSpreeSearchHistories < ActiveRecord::Migration[6.0]
  def change
    create_table :spree_search_histories do |t|
      t.string :title

      t.timestamps
    end
  end
end
