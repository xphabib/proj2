class CreateSpreeSslCommerzCheckouts < ActiveRecord::Migration[6.0]
  def change
    create_table :spree_ssl_commerz_checkouts do |t|
      t.string :tran_id
      t.string :val_id
      t.string :amount
      t.string :card_type
      t.string :store_amount
      t.string :card_no
      t.string :bank_tran_id
      t.string :status
      t.string :tran_date
      t.string :error
      t.string :currency
      t.string :card_issuer
      t.string :card_brand
      t.string :card_sub_brand
      t.string :card_issuer_country
      t.string :card_issuer_country_code
      t.string :store_id
      t.string :verify_sign
      t.string :verify_key
      t.string :verify_sign_sha2
      t.string :currency_type
      t.string :currency_amount
      t.string :currency_rate
      t.string :base_fair
      t.string :value_a
      t.string :value_b
      t.string :value_c
      t.string :value_d
      t.string :risk_level
      t.string :risk_title

      t.timestamps
    end
  end
end
