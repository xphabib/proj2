class AddIndexToSpreeSearchHistories < ActiveRecord::Migration[6.0]
  def change
    add_index :spree_search_histories, :title
  end
end
