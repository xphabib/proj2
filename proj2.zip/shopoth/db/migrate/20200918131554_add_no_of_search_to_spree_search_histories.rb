class AddNoOfSearchToSpreeSearchHistories < ActiveRecord::Migration[6.0]
  def change
    add_column :spree_search_histories, :no_of_search, :integer, default: 0
  end
end
