# frozen_string_literal: true
module CommonHelper
  extend Grape::API::Helpers

  def prepare_order_history(order_list)
    orders = format_completed_at(order_list)
    grouped_data = orders.group_by(&:completed_at)
    grouped_data.map do |key, val|
      {
        date: format_date(key),
        order_list: process_order_list(val),
      }
    end
  end

  def prepare_return_history(return_list)
    grouped_data = return_list.group_by(&:created_at)
    grouped_data.map do |key, val|
      {
          date: format_date(key),
          order_list: process_return_list(val),
      }
    end
  end

  def format_completed_at(orders)
    orders.map do |order|
      order.update(completed_at: format_date(order.completed_at))
      order
    end
  end

  def format_date(time)
    time&.strftime("%d/%m/%Y")
  end

  def process_order_list(order_list)
    order_list.map do |order|
      address = order.shipping_address
      partner_commission = 0
      # partner_commission = order&.induced? ? order&.partner_commission.to_f : 0
      order_price = order.total_price - partner_commission
      {
        order_id: order.id,
        customer_name: order.customer&.name,
        order_type: order.order_type,
        phone: order.customer&.phone,
        amount: order_price,
        area: address&.area&.name,
      }
    end
  end

  def process_return_list(return_list)
    return_list.map do |return_order|
      address = return_order&.customer_order.shipping_address
      {
          order_id: return_order&.id,
          customer_name: return_order&.customer_order&.customer&.name,
          order_type: return_order&.customer_order&.order_type,
          phone: return_order&.customer_order&.customer&.phone,
          amount: return_order&.customer_order&.cart_total_price,
          area: address&.area&.name,
      }
    end
  end
end
