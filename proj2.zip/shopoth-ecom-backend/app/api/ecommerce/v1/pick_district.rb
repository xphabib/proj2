module Ecommerce
  module V1
    class PickDistrict < Ecommerce::Base
      namespace 'select' do
        desc 'Get homepage category'
        route_setting :authentication, optional: true
        get '/districts' do
          present District.all, with: Ecommerce::V1::Entities::Districts
        end

        desc 'Get warehouse id'
        route_setting :authentication, optional: true
        get '/district/:id/warehouse' do
          warehouse_ids = Warehouse.where(warehouse_type: 'distribution').joins(address: :district).where("districts.id = ?", params[:id]).pluck(:id)
          if warehouse_ids.empty?
            { message: 'Sorry no warehouse found' }
          else
            { warehouse_ids: warehouse_ids }
          end
        rescue => err
          error!("Unable to process request #{err}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end
      end
    end
  end
end