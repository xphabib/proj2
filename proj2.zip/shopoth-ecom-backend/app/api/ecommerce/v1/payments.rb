require 'net/http'

module Ecommerce
  module V1
    class Payments < Ecommerce::Base
      helpers do
        def order
          @order = CustomerOrder.find(params[:order_id])
        end

        def payment
          @payment = Payment.find_by!(
            id: params['tran_id'],
            currency_amount: params['currency_amount'],
            currency_type: params['currency_type'],
          )
        end

        def cancel_order(customer_order)
         customer_order.update!(order_status_id: OrderStatus.find_by(order_type: OrderStatus.order_types[:cancelled]).id,
                                         cancellation_reason: 'Payment transaction not valid',
                                         pay_status: CustomerOrder::pay_statuses[:payment_failed],
                                         changed_by: @current_user)
        end
      end

      resources :payment do
        resources :cash_on_delivery do
          desc 'Initiate a payment through COD'
          params do
            requires :order_id, type: Integer
          end

          post '/initiate' do
            # payment_session = PaymentManagement::CashOnDelivery::InitiatePayment.call(
            #   order: order,
            #   order_status: order.status,
            #   form_of_payment: :cash,
            #   payment_status: :pending,
            #   customer: @current_user,
            # )
            #
            # if payment_session.success?
            respond_with_json('successful', HTTP_CODE[:OK])
            # else
            #   # PaymentManagement::SendPaymentFailureEmail.call(order: order)
            #   error!(payment_session.error, HTTP_CODE[:UNPROCESSABLE_ENTITY])
            # end
          end

          desc 'Update the COD Payment as successful after delivery'
          params do
            requires :tran_id, type: String
            requires :currency_type, type: String
            requires :currency_amount, type: String
          end

          post '/finalize' do
            payment_session = PaymentManagement::CashOnDelivery::FinalizePayment.call(
              payment: payment,
              status: :successful,
              order_status: payment.customer_order.status,
              order_delivered: OrderStatus.getOrderStatus(OrderStatus.order_types[:completed]),
            )

            if payment_session.success?
              respond_with_json('successful', HTTP_CODE[:OK])
            else
              error!(
                payment_session.error,
                HTTP_CODE[:UNPROCESSABLE_ENTITY],
              )
            end
          end
        end

        resources :credit_card do
          desc 'Initiate a payment through Credit Card'
          params do
            requires :order_id, type: Integer
          end

          post '/initiate' do
            Rails.logger.info "Initiating SSL Commerz Payment for Order: #{order.id} at #{DateTime.now.in_time_zone('Dhaka')}"
            payment_session = PaymentManagement::CreditCard::InitiatePayment.call(
              order: order,
              form_of_payment: :credit_card,
              payment_status: :pending,
              customer: @current_user,
            )

            if payment_session.success?
              respond_with_json({ redirect_url: payment_session.gateway_page_url }, HTTP_CODE[:OK])
            else
              error!(payment_session.error, HTTP_CODE[:UNPROCESSABLE_ENTITY])
            end
          end

          resources :ipn do
            desc 'GET: Listen to Instant Payment Notification(IPN) from SSLCOMMERZ'
            params do
              requires :status, type: String
              given status: ->(val) { val == 'valid' } do
                requires :val_id, type: String
              end
              requires :tran_id, type: String
              optional :risk_level
              requires :currency_type, type: String
              requires :currency_amount, type: String
            end

            route_setting :authentication, optional: true
            get do
              Rails.logger.info "GET: IPN request from SSLCommerz for Transaction: #{payment.id}, Order: #{payment.customer_order.id} at #{DateTime.now.in_time_zone('Dhaka')}"
              Rails.logger.info "IPN request params: #{params.inspect} at #{DateTime.now.in_time_zone('Dhaka')}"
              request_validation = PaymentManagement::CreditCard::HandleIpnRequest.call(
                payment: payment,
                order: payment.customer_order,
                status: params['status'],
                val_id: params['val_id'],
                risk_level: params['risk_level'],
              )

              if request_validation.success?
                payment&.customer_order&.customer_paid!
                Rails.logger.info "IPN request successfully validated Transaction: #{payment.id}"
              else
                # PaymentManagement::SendPaymentFailureEmail.call(order: payment.customer_order)
                cancel_order(payment.customer_order)
                Rails.logger.error "IPN request could not validate Transaction: #{payment.id}"
              end
            end

            desc 'POST: Listen to Instant Payment Notification(IPN) from SSLCOMMERZ'
            params do
              requires :status, type: String
              given status: ->(val) { val == 'valid' } do
                requires :val_id, type: String
              end
              requires :tran_id, type: String
              optional :risk_level
              requires :currency_type, type: String
              requires :currency_amount, type: String
            end
            route_setting :authentication, optional: true

            post do
              Rails.logger.info "POST: IPN request from SSLCommerz for Transaction: #{payment.id}, Order: #{payment.customer_order.id} at #{DateTime.now.in_time_zone('Dhaka')}"
              Rails.logger.info "IPN request params: #{params.inspect} at #{DateTime.now.in_time_zone('Dhaka')}"

              request_validation = PaymentManagement::CreditCard::HandleIpnRequest.call(
                payment: payment,
                order: payment.customer_order,
                status: params['status'],
                val_id: params['val_id'],
                risk_level: params['risk_level'],
              )

              if request_validation.success?
                payment&.customer_order&.customer_paid!
                Rails.logger.info "IPN request successfully validated Transaction: #{payment.id}"
              else
                # PaymentManagement::SendPaymentFailureEmail.call(order: payment.customer_order)
                cancel_order(payment.customer_order)
                Rails.logger.error "IPN request could not validate Transaction: #{payment.id}"
              end
            end
          end
        end

        resources :wallet do
          desc 'Initiate a payment through Wallet'
          params do
            requires :order_id, type: Integer
          end

          post '/initiate' do
            payment_session = PaymentManagement::Wallet::InitiatePayment.call(
              order: order,
              order_status: order.status,
              form_of_payment: :wallet,
              payment_status: :pending,
              customer: @current_user,
            )

            if payment_session.success?
              order&.customer_paid!
              respond_with_json('successful', HTTP_CODE[:OK])
            else
              # PaymentManagement::SendPaymentFailureEmail.call(order: order)
              cancel_order(order)
              error!(payment_session.error, HTTP_CODE[:UNPROCESSABLE_ENTITY])
            end
          end

          desc 'Update the Wallet Payment as successful after delivery'
          params do
            requires :tran_id, type: String
            requires :currency_type, type: String
            requires :currency_amount, type: String
          end

          post '/finalize' do
            payment_session = PaymentManagement::CashOnDelivery::FinalizePayment.call(
              payment: payment,
              status: :successful,
              order_status: payment.customer_order.status,
              order_delivered: OrderStatus.getOrderStatus(OrderStatus.order_types[:completed]),
            )

            if payment_session.success?
              respond_with_json('successful', HTTP_CODE[:OK])
            else
              error!(
                payment_session.error,
                HTTP_CODE[:UNPROCESSABLE_ENTITY],
              )
            end
          end
        end

        resources :bkash do
          desc 'Create a payment through Bkash'
          params do
            requires :order_id, type: Integer
          end

          post '/create' do
            payment_session = PaymentManagement::Bkash::CreatePayment.call(
              order: order,
              order_status: order.status,
              form_of_payment: :bkash,
              payment_status: :pending,
              customer: @current_user,
            )

            if payment_session.success?
              order&.customer_paid!
              respond_with_json({ payment_id: payment_session.payment_id, order_id: payment_session.order_id }, HTTP_CODE[:OK])
            else
              # PaymentManagement::SendPaymentFailureEmail.call(order: order)
              cancel_order(order)
              error!(payment_session.error, HTTP_CODE[:UNPROCESSABLE_ENTITY])
            end
          end

          desc 'Execute the bkash payment'
          params do
            requires :payment_id, type: String
            requires :order_id, type: String
          end

          post '/execute' do
            payment = Payment.find_by!(customer_order_id: params[:order_id])
            payment_session = PaymentManagement::Bkash::ExecutePayment.call(
              payment_id: params[:payment_id],
              payment: payment,
            )

            if payment_session.success?
              payment&.customer_order&.customer_paid!
              respond_with_json({ payment_id: payment_session.new_payment_id }, HTTP_CODE[:OK])
            else
              cancel_order(payment.customer_order)
              error!(
                payment_session.error,
                HTTP_CODE[:UNPROCESSABLE_ENTITY],
              )
            end
          end
        end

        resources :nagad do
          desc 'Complete a payment through Nagad'
          params do
            requires :order_id, type: Integer
            requires :ip_address, type: String
          end

          post '/complete' do
            payment_session = PaymentManagement::Nagad::CompletePayment.call(
              order: order,
              ip_address: params[:ip_address],
              order_status: order.status,
              form_of_payment: :nagad,
              payment_status: :pending,
              customer: @current_user,
            )

            if payment_session.success?
              order&.customer_paid!
              puts payment_session.callback_url
              respond_with_json({ redirect_url: payment_session.callback_url }, HTTP_CODE[:OK])
            else
              cancel_order(order)
              error!(payment_session.error, HTTP_CODE[:UNPROCESSABLE_ENTITY])
            end
          end
        end
      end
    end
  end
end
