# frozen_string_literal: true

class Ecommerce::V1::Brands < Ecommerce::Base
  helpers do
    def json_response(brand)
      brand.as_json(
        only: [:name]
      ).merge({ main_image: image_path(brand.image), hover_image: image_path(brand.hover_image)})
    end
  end

  resource :brands do
    # Create a brand with regular and hover image
    desc 'Create brand'
    params do
      requires :name, type: String
      requires :main_image
      requires :hover
    end
    post do
      brand = Brand.new(params)
      if brand.save
        json_response(brand)
      else
        respond_with_json('Creation failed', 500)
      end
    rescue => ex
      respond_with_json("Error due to #{ex.message}", 500)
    end

    # Update a brand
    route_param :id do
      params do
        optional :name, type: String
        optional :main_image
        optional :hover
      end
      put '/update' do
        brand = Brand.find(params[:id])
        if brand
          json_response(brand) if brand.update(params)
        end
      rescue => ex
        respond_with_json("Can not update due to #{ex.message}", 500)
      end
    end

    # Delete
    route_param :id do
      delete do
        if brand = Brand.find(params[:id])
          respond_with_json('Successfully deleted', 200) if brand.destroy
        else
          respond_with_json('Unsuccessful', 500)
        end
      rescue => ex
        respond_with_json("Can not delete due to #{ex.message}", 500)
      end
    end
  end
end



