module Ecommerce
  module V1
    class Notifications < Ecommerce::Base
      resources :notifications do
        desc 'Get all notifications of the logged in user'
        get do
          @current_user.notifications.update_all(read: true)
          present @current_user.notifications.order('id DESC'), with: Ecommerce::V1::Entities::Notification
        end


        desc 'Unread notifications count'
        get '/unread_count' do
          notification_count = @current_user.notifications.where(read: false).count
          {count: notification_count}
        end

        desc 'Create a notification'
        params do
          optional :details, type: String
        end

        post do
          declared_params = declared(params)

          notification = Notification.new(
            user: @current_user,
            details: declared_params[:details],
          )

          if notification.save
            present notification, with: Ecommerce::V1::Entities::Notification
          else
            respond_with_json(
              notification.errors.full_messages.to_sentence,
              HTTP_CODE[:UNPROCESSABLE_ENTITY],
            )
          end
        end

        route_param :id do
          helpers do
            def notification
              @notification ||= Notification.find(params[:id])
            end
          end

          desc 'Update a notification'
          params do
            optional :details, type: String
            optional :read, type: Boolean
          end

          put do
            declared_params = declared(params, include_missing: false)

            if notification.update(declared_params)
              present notification, with: Ecommerce::V1::Entities::Notification

            else
              respond_with_json(
                notification.errors.full_messages.to_sentence,
                HTTP_CODE[:UNPROCESSABLE_ENTITY],
              )
            end
          end
        end

        desc 'Mark all notifications as read'
        post '/mark_all_read' do
          notifications = @current_user.notifications
          notifications.update_all read: true
          present notification, with: Ecommerce::V1::Entities::Notification
        end
      end
    end
  end
end
