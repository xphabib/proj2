# frozen_string_literal: true

module Ecommerce
  module V1
    class Reviews < Ecommerce::Base
      resource :reviews do
        # GET ALL REVIEWS FOR ADMIN
        desc 'RETURN ALL REVIEWS'
        get do
          all_reviews = Review.select(:id, :title, :body, :rating, :review_type, :product_id, :user_id)
        rescue StandardError => ex
          respond_with_json("Something went wrong due to #{ex.message}", 422)
        end

        # CREATE REVIEW FOR A PRODUCT BY A USER
        desc 'CREATE REVIEW FOR A PRODUCT BY A USER'
        params do
          requires :title, type: String
          requires :rating, type: Integer
          requires :product_id, type: Integer
          optional :body, type: String
        end
        post do
          review = Review.new(params)
          review.user_id = @current_user.id
          review.is_approved = false if params[:rating].between?(0, 2)
          if review.save
            review
          else
            respond_with_json('Unsuccesful', 422)
          end
        rescue StandardError => ex
          respond_with_json("Can not create due to #{ex.message}", 422)
        end

        # UPDATE A REVIEW
        route_param :id do
          params do
            optional :title, type: String
            optional :body, type: String
            optional :rating, type: String
            optional :review_type, type: String
          end
          put do
            review = Review.find(params[:id])
            if review.user_id == @current_user.id.to_i
              review.update(params)
              review
            else
              respond_with_json('Unsuccesful', HTTP_CODE[:INTERNAL_SERVER_ERROR])
            end
          rescue StandardError => ex
            respond_with_json("Can not update due to #{ex.message}", 422)
          end
        end

        # DELETE A REVIEW
        route_param :id do
          delete do
            if @current_user
              review = Review.find(params[:id])
              respond_with_json('Successful', 200) if review.destroy
            end
          rescue StandardError => ex
            respond_with_json("Can not delete due to #{ex.message}", 422)
          end
        end
      end
    end
  end
end

