# frozen_string_literal: true

module Ecommerce::V1::Serializers
  module ProductCategorySerializer
    extend Grape::API::Helpers

    include Ecommerce::V1::Helpers::ImageHelper

    def get_category_info(category)
      Jbuilder.new.category do |json|
        json.id category.id
        json.title category.title
        json.bn_title category.bn_title
        json.image_url image_path(category.image)
      end
    end

    def show_by_product_category(products)
      Jbuilder.new.products do |json|
        json.array! products do |product|
          json.id product.id
          json.title product.title
          json.bn_title product.bn_title
          json.image_url product.master_img('product')
          # TODO: Product view url
          # json.view_url show_product_page(product.id)
          json.price product.get_product_base_price.to_i
          json.discount product.discount
          json.discount_stringified product.discount_stringify
          json.effective_mrp product.discounted_price.to_i
          json.product_rating product.get_product_avg_rating
        end
      end
    end

    def show_product_page(id)
      # TODO: Product view url
    end
  end
end
