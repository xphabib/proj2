# frozen_string_literal: true
module Ecommerce::V1::Serializers
  module ProductSerializer
    extend Grape::API::Helpers

    def get_product_details(product, variants, warehouse)
      Jbuilder.new.key do |json|
        json.product_id product.id
        json.title product.title
        json.description product.description
        json.short_description product.short_description
        # json.rating product.get_product_avg_rating
        json.product_images select_product_main_img(product)
        # json.total_reviews product.total_reviews
        # TODO: Category expose
        # json.product_categories product.categories do |category|
        #   json.id category.id
        #   json.title category.title
        #   json.bn_title category.bn_title
        # end
        json.variants get_variants_details(variants, warehouse)
        if product.product_attribute_images.present?
          json.product_attribute_images do
            product.product_attribute_images&.each { |pa| json.set! pa.product_attribute_value_id, image_paths(pa.images) || [""] }
          end
        else
          json.product_attribute_images []
        end
      end
    end

    def select_product_main_img(product)
      product_image = image_paths(product.images)
      product_image.nil? ? [product.master_img('product')] : product_image
    end

    def get_variants_details(variants, warehouse)
      Jbuilder.new.key do |json|
        json.array! variants do |variant|
          json.variant_id variant.id
          json.product_attribute_values variant.product_attribute_values.ids
          json.sku variant.sku
          json.weight variant.weight
          json.height variant.height
          json.price variant.price_consumer.to_i
          json.discount variant.fetch_discount
          json.available_quantity get_available_quantity(variant, warehouse)
          json.is_available get_available_quantity(variant, warehouse).positive? ? true : false
          json.effective_mrp variant.consumer_final_price.to_i
          json.discount_type variant.discount_type
        end
      end
    end

    def get_review(reviews)
      Jbuilder.new.key do |json|
        json.array! reviews do |review|
          json.review_id review.id
          json.title review.title
          json.body review.body
          json.rating review.rating
          json.user review&.user&.name
        end
      end
    end

    def get_available_quantity(variant, warehouse)
      variant&.warehouse_variants.find_by(warehouse_id: warehouse.id)&.available_quantity
    end
  end
end
