module Ecommerce::V1::Serializers
  module HomepageSerializer
    extend Grape::API::Helpers

    def image_path(obj)
      obj.service_url if obj.attached?
    end

    def to_slider_json(sliders)
      Jbuilder.new.sliders do |json|
        json.array! sliders do |slider|
          json.name slider.name
          json.body slider.body
          json.link_url slider.link_url
          json.position slider.position
          json.img_type slider.img_type
          json.slider_url slider.image_url
        end
      end
    end

    def get_homepage_product_list(products)
      Jbuilder.new.key do |json|
        json.array! products do |product|
          json.id product.id
          json.title product.title
          json.price product.get_product_base_price.to_i
          json.discount product.discount
          json.discount_stringified product.discount_stringify
          json.effective_mrp product.discounted_price.to_i
          json.product_rating product.get_product_avg_rating
          json.view_url get_product_show_url(product.id)
          json.image_url image_path(product.main_image)
        end
      end
    end

    def get_product_search_json(products)
      Jbuilder.new.key do |json|
        json.array! products do |product|
          json.id product.id
          json.title product.title
          json.mini_img product.master_img('mini')
          json.image_url product.master_img('product')
          json.price product.get_product_base_price.to_i
          json.view_url get_product_show_url(product.id)
          json.discount product.discount
          json.discount_stringified product.discount_stringify
          json.effective_mrp product.discounted_price.to_i
        end
      end
    end

    def get_product_show_url(id)
      "/products/details/#{id}"
    end

    # Get menu
    def menu_category(lists)
      Jbuilder.new.key do |json|
        json.array! lists do |list|
          json.id list.id
          json.title list.title
          json.bn_title list.bn_title
          json.image image_path(list.image)
          json.sub_categories list.sub_categories.where(home_page_visibility: true).order(:position).includes(:sub_categories) do |sub_category|
            json.id sub_category.id
            json.title sub_category.title
            json.bn_title sub_category.bn_title
            json.view_url get_category_url(sub_category.id)
            json.sub_sub_categories sub_category.sub_categories.where(home_page_visibility: true).order(:position) do |sub_cat|
              json.id sub_cat.id
              json.title sub_cat.title
              json.bn_title sub_cat.bn_title
              json.view_url get_category_url(sub_cat.id)
            end
          end
        end
      end
    end

    # Get shop_by_category
    def get_shop_by_category(categories)
      Jbuilder.new.key do |json|
        json.array! categories do |category|
          json.id category.id
          json.title category.title
          json.bn_title category.bn_title
          json.image image_path(category.image)
          json.view_url get_category_url(category.id)
        end
      end
    end

    def get_category_url(id)
      "/product_category/#{id}"
    end

    def get_brand_info(brands)
      Jbuilder.new.key do |json|
        json.array! brands do |brand|
          json.name brand.name
          json.main_image image_path(brand.image)
          json.hover_image image_path(brand.hover_image)
        end
      end
    end
  end
end
