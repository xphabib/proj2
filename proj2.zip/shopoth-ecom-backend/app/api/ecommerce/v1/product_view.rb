# frozen_string_literal: true

class Ecommerce::V1::ProductView < Ecommerce::Base
  helpers Ecommerce::V1::Serializers::ProductSerializer

  helpers do
    def get_attributes(variants)
      variants = variants.includes(product_attribute_values: :product_attribute)
      variants.map do |variant|
        variant.product_attribute_values.map do |prod_attr_value|
          {
            product_attribute_name: prod_attr_value&.product_attribute&.name,
            product_attribute_value_id: prod_attr_value.id,
            product_attribute_value_name: prod_attr_value.value,
          }
        end
      end.flatten.uniq.group_by { |h| h[:product_attribute_name] }
    end

    def product_attributes(attribute_variants)
      product_attribute = attribute_variants
      product_attribute.map do |key, value|
        {
          product_attribute_name: key,
          product_attribute_values: value.map { |h| { id: h[:product_attribute_value_id], value: h[:product_attribute_value_name] } },
        }
      end
    end
  end

  namespace 'products' do
    route_param :id do
      params do
        requires :warehouse_id, type: Integer
      end
      route_setting :authentication, optional: true
      get do
        warehouse = Warehouse.find(params[:warehouse_id])
        product = warehouse.products&.where('warehouse_variants.available_quantity > ?', 0).find_by(id: params[:id])
        if product
          variants = warehouse.variants.where(product_id: product.id).
                     where('warehouse_variants.available_quantity > ?', 0).order('variants.effective_mrp ASC')
          product_attribute = product_attributes(get_attributes(variants))
          # reviews = get_review Review.where(product_id: params[:id]).includes(:user)
          { product_attribute: product_attribute, product: get_product_details(product, variants, warehouse) }
        else
          respond_with_json('Not Found', HTTP_CODE[:NOT_FOUND])
        end
      rescue StandardError => error
        error!("Can not show due to #{error}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
      end
    end
  end
end
