module Ecommerce
  module V1
    class Otps < Ecommerce::Base
      resources :otps do
        desc 'Sends an OTP to given phone number and returns encrypted hash'
        route_setting :authentication, optional: true

        params do
          requires :phone, type: String
        end

        post '/send' do
          otp = SmsManagement::SendOtp.call(phone: params[:phone])

          if otp.success?
            respond_with_json(otp.token, HTTP_CODE[:OK])
          else
            error!(otp.error, HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end
        end

        desc 'Verify an otp'
        route_setting :authentication, optional: true

        params do
          requires :phone, type: String
          requires :otp, type: Integer
          requires :token, type: String
        end

        helpers do
          def user
            @user ||= User.find_by!(phone: params[:phone])
          end
        end

        post '/verify' do
          otp = SmsManagement::VerifyOtp.call(phone: params[:phone], otp: params[:otp], token: params[:token])

          if otp.success?
            user.update_attribute(:status, :active)
            respond_with_json('verified', HTTP_CODE[:OK])
          else
            error!('OTP does not match!', HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end
        end


        desc 'New Verify generate'
        route_setting :authentication, optional: true

        params do
          requires :token, type: String
        end

        post '/new_otp' do
          auth_key = AuthorizationKey.find_by(token: params[:token])
          otp = JsonWebToken.encode_otp(auth_key.user)
          if otp
            respond_with_json(otp.token, HTTP_CODE[:OK])
          else
            error!(otp.error, HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end
        rescue => err
          error!("Unable to process request #{err}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end
      end
    end
  end
end