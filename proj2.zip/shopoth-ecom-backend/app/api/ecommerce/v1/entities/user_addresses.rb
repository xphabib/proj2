# frozen_string_literal: true

module Ecommerce::V1::Entities
  class UserAddresses < Grape::Entity
    expose :id
    expose :thana
  end
end
