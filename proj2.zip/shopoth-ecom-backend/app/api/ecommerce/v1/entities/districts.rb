module Ecommerce
  module V1
    module Entities
      class Districts < Grape::Entity
        expose :id
        expose :name
        expose :bn_name
      end
    end
  end
end
