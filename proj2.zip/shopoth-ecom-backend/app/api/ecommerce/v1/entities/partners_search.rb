module Ecommerce
  module V1
    module Entities
      class PartnersSearch < Grape::Entity
        include ShopothWarehouse::V1::Helpers::ImageHelper

        expose :id
        expose :name
        expose :phone
        expose :schedule
        expose :image
        expose :outlet_name
        expose :latitude
        expose :longitude
        expose :address

        def address
          {
            district_name: object&.address&.district&.name,
            thana_name: object&.address&.thana&.name,
            area_name: object&.address&.area&.name,
            address_line: object&.address&.address_line,
            post_code: object&.address&.zip_code,
          }
        end

        def image
          begin
            image_variant_path(object&.image)&.dig(:small_img)
          rescue ActiveStorage::FileNotFoundError
            nil
          rescue => _error
            nil
          end
        end
      end
    end
  end
end
