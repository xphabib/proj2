# frozen_string_literal: true

module Ecommerce
  module V1
    class CustomerOrders < Ecommerce::Base
      helpers Ecommerce::V1::Serializers::CustomerOrderSerializer

      helpers do
        def fetch_ongoing_statuses
          OrderStatus.select do |status|
            %w(cancelled completed in_transit_cancelled).include?(status.order_type.to_s)
          end
        end

        def phone_validation(partner_phone, user_phone)
          if partner_phone == user_phone
            error!('User and Partner phone number can not be same', HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end
        end

        def cart
          @cart = Cart.find(params[:cart_id])
        rescue ActiveRecord::RecordNotFound => error
          error!("Unable to find cart #{error}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end

        def check_zero_item(cart)
          cart.shopoth_line_items.map(&:quantity).all?(&:positive?)
        end
      end

      resource :customer_orders do
        desc 'Show Customer Ongoing Orders'
        get '/ongoing-orders' do
          cancelled_statuses = fetch_ongoing_statuses
          get_customer_orders @current_user.customer_orders.where.
            not(status: cancelled_statuses).order(id: :desc)
        rescue StandardError => error
          error!("Unable to fetch due to #{error}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end

        desc 'Show cancelled orders'
        get '/cancelled-orders' do
          cancelled_status_ids = OrderStatus.where(order_type: %w(cancelled in_transit_cancelled)).ids
          get_customer_orders @current_user.customer_orders.where(order_status_id: cancelled_status_ids).order(id: :desc)
        rescue StandardError => error
          error!("Unable to fetch due to #{error}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end

        desc 'Show completed orders'
        get '/completed-orders' do
          completed_status_id = OrderStatus.getOrderStatus(OrderStatus.order_types[:completed]).id
          get_customer_orders CustomerOrder.completed_orders(@current_user.id, completed_status_id).order(id: :desc)
        rescue StandardError => error
          error!("Unable to fetch due to #{error}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end

        desc 'Show Details of One Customer'
        route_param :id do
          get do
            order = @current_user.customer_orders.find(params[:id])
            get_specific_order_details order
          rescue StandardError => error
            error!(error, HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end
        end

        desc 'Create Order with Cart Items'
        params do
          requires :cart_id, type: Integer
          requires :shipping_type, type: String
          optional :new_address, type: Hash do
            requires :first_name, type: String
            requires :last_name, type: String
            requires :district_id, type: Integer
            requires :thana_id, type: Integer
            requires :area_id, type: Integer
            requires :home_address, type: String
            requires :phone, type: String
            optional :alternative_phone, type: String
            optional :post_code, type: Integer
          end
          optional :partner_id, type: Integer
          optional :rider_id, type: Integer
          optional :billing_address_id, type: Integer
          optional :shipping_address_id, type: Integer
          requires :form_of_payment, type: String
          requires :shipping_charge, type: BigDecimal
        end
        post do
          current_cart = cart
          unless current_cart.check_minimum_cart_value
            error!(respond_with_json('Cart value must be greater or equal to 180tk', HTTP_CODE[:UNPROCESSABLE_ENTITY]),
                   HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end
          unless check_zero_item(current_cart)
            error! respond_with_json('Please provide valid quantity', HTTP_CODE[:NOT_FOUND])
          end

          partner = Partner.find(params[:partner_id]) if params[:partner_id].present?
          rider = Rider.find(params[:rider_id]) if params[:rider_id].present?

          phone_validation(partner.phone, params[:new_address][:phone]) if partner.present?

          order_context = OrderManagement::CreateCustomerOrder.call(
            customer: @current_user,
            cart: current_cart,
            billing_address_id: params[:billing_address_id].to_i,
            shipping_address_id: params[:shipping_address_id].to_i,
            shipping_type: params[:shipping_type],
            new_address: params[:new_address],
            form_of_payment: params[:form_of_payment],
            partner: partner,
            rider: rider,
            shipping_charge: params[:shipping_charge],
            order_type: 'organic',
            customer_orderable: @current_user
          )

          if order_context.success?
            CreateNotification.call(
              user: order_context.order.customer,
              message: Notification.get_notification_message(order_context.order),
            )
            order_context.order
          else
            error!(order_context.error, HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end
        rescue ActiveRecord::RecordNotFound => error
          error!(error, HTTP_CODE[:UNPROCESSABLE_ENTITY])
        rescue StandardError => error
          error!(error, HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end
      end
    end
  end
end
