class Ecommerce::V1::ProductCategory < Ecommerce::Base
  helpers Ecommerce::V1::Serializers::ProductCategorySerializer
  helpers Ecommerce::V1::Helpers::FilterHelper

  namespace 'product_category' do
    desc 'Get all product in a category'
    route_param :id do
      route_setting :authentication, optional: true
      params do
        optional :column, type: String
        optional :direction, type: String, default: 'asc', values: %w(asc desc)
        optional :warehouse_id, type: Integer
      end
      get do
        category = Category.find(params[:id])
        cat_info = get_category_info category
        warehouse = Warehouse.find(params[:warehouse_id]) if params[:warehouse_id]
        products = warehouse ? warehouse.products.joins(:categories).where(categories: {id: category.id}).where('warehouse_variants.available_quantity > ?', 0) : category.products

        column = params[:column]
        direction = params[:direction]
        if column && direction
          products = Product.sort(products, column, direction)
        end

        product_category = show_by_product_category(paginate(Kaminari.paginate_array(products)))
        { category: cat_info, product_category: product_category }
      rescue StandardError => ex
        error!("Unable to fetch due to #{ex.message}",
                          HTTP_CODE[:UNPROCESSABLE_ENTITY])
      end
    end

    desc 'Get all filter options'
    route_setting :authentication, optional: true
    get '/:id/filter_options' do
      category = Category.find(params[:id])
      get_filter_options(category.products)
    end

    desc 'Filter Products based on a category'
    # Option Auth for category based filter route
    # Add params where needed
    params do
      optional :min_price, type: String
      optional :max_price, type: String
      requires :category_ids, type: Array
      optional :product_attribute_ids, type: Array
      optional :product_attribute_value_ids, type: Array
    end
    route_setting :authentication, optional: true
    # TODO: violating http protocol 'post' should be 'get' (Will remove after elastic search is implemented)
    post '/filter' do
      products = Product.joins(:product_categories).where('product_categories.category_id IN (?)', params[:category_ids])
        # Helper method used, so we can quickly switch/add/remove the filters
      filtered_products = apply_filter(
        params,
        products
      )
      # Serializing as ProductCategorySerialized Defined before
      result = show_by_product_category(paginate(Kaminari.paginate_array(filtered_products)))
      result
    rescue StandardError => ex
      respond_with_json("Unable to fetch due to #{ex.message}",
                        HTTP_CODE[:INTERNAL_SERVER_ERROR])
    end
  end
end
