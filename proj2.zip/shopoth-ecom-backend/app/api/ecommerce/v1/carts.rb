# frozen_string_literal: true

module Ecommerce
  module V1
    class Carts < Ecommerce::Base
      helpers Ecommerce::V1::Serializers::CartShowSerializer

      helpers do
        def quantity_available?(quantity, variant, warehouse)
          available_quantity = WarehouseVariant.find_by(variant_id: variant.id, warehouse_id: warehouse.id).available_quantity
          available_quantity >= quantity
        end

        def current_quantity
          line_item = @current_cart.shopoth_line_items.find_by(variant_id: @variant.id)
          line_item ? line_item.quantity + params[:quantity] : params[:quantity]
        end

        def error_message!
          error!({ unavailable: 'Can not add due to unavailable quantity' })
        end

        def current_item_delete(current_cart, current_item)
          if current_item.destroy
            current_cart.update!(current_cart.cart_attributes)
            respond_with_json('Successfully deleted', 200)
          else
            respond_with_json('Can not be deleted', HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end
        end
      end

      resource :carts do
        # Get all shopoth line items in cart
        desc 'Get all shopoth_line_item in cart'
        route_param :id do
          route_setting :authentication, optional: true
          get do
            cart = Cart.find(params[:id])
            show_item_in_cart cart
          rescue StandardError => error
            error!("Cannot show due to #{error.message}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end
        end

        # create a cart and populate with shopoth_line_items
        desc 'Create a cart'
        params do
          requires :warehouse_id, type: Integer
          requires :variant_id, type: Integer
          requires :quantity, type: Integer, values: ->(v) { v.positive? }
        end
        route_setting :authentication, optional: true
        post do
          warehouse = Warehouse.find(params[:warehouse_id])
          variant = warehouse.variants.find(params[:variant_id])
          if quantity_available?(params[:quantity], variant, warehouse) == true
            cart = Cart.create!
            shopoth_line_item = cart.add_cart(variant, params[:quantity])
            cart.update!(cart.cart_attributes)
            present shopoth_line_item, with: Ecommerce::V1::Entities::CartCreation
          else
            error_message!
          end
        rescue StandardError => error
          error!("Cannot create due to #{error.message}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end

        # Update cart
        desc 'Update Cart'
        route_param :id do
          put do
            current_cart = Cart.find(params[:id])
            # TODO: Users old cart will be merged in future, for now it is deleted
            if @current_user.cart
              cart = @current_user.cart
              cart.destroy_with_shopoth_line_items unless cart.id == current_cart.id
            end
            current_cart.user_id = @current_user.id
            current_cart.update!(current_cart.cart_attributes)
            show_item_in_cart current_cart
          rescue StandardError => error
            error!("Cannot update due to #{error.message}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end

          resource :shopoth_line_items do
            params do
              requires :variant_id, type: Integer
              requires :quantity, type: Integer, values: ->(v) { v.positive? }
              requires :warehouse_id, type: Integer
            end
            route_setting :authentication, optional: true
            put do
              warehouse = Warehouse.find(params[:warehouse_id])
              @current_cart = Cart.find(params[:id])
              @variant = warehouse.variants.find(params[:variant_id])
              error_message! if quantity_available?(current_quantity, @variant, warehouse) == false
              shopoth_line_item = @current_cart.add_cart(@variant, params[:quantity])
              @current_cart.update!(@current_cart.cart_attributes)
              present shopoth_line_item, with: Ecommerce::V1::Entities::CartCreation
            rescue StandardError => error
              error!("Cannot update due to #{error.message}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
            end

            # remove from cart
            route_param :shopoth_line_item_id do
              route_setting :authentication, optional: true
              delete do
                current_cart = Cart.find(params[:id])
                current_item = ShopothLineItem.find(params[:shopoth_line_item_id])
                if !!current_item && !!current_cart
                  current_item_delete(current_cart, current_item)
                end
              rescue StandardError => error
                error!("Cannot remove due to #{error.message}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
              end
            end

            # add by one
            desc 'Add by one quantity'
            route_setting :authentication, optional: true
            route_param :shopoth_line_item_id do
              params do
                requires :warehouse_id, type: Integer
              end
              put '/add-one' do
                warehouse = Warehouse.find(params[:warehouse_id])
                current_cart = Cart.find(params[:id])
                shopoth_line_item = ShopothLineItem.find(params[:shopoth_line_item_id])
                if quantity_available?(shopoth_line_item.quantity + 1, shopoth_line_item.variant, warehouse)
                  shopoth_line_item.quantity += 1
                  shopoth_line_item.discount_amount = shopoth_line_item.variant.consumer_discount_amount * shopoth_line_item.quantity
                  shopoth_line_item.sub_total = (shopoth_line_item.total_price - shopoth_line_item.discount_amount).ceil
                  shopoth_line_item.save!
                  current_cart.update!(current_cart.cart_attributes)
                  present shopoth_line_item, with: Ecommerce::V1::Entities::CartCreation
                else
                  error_message!
                end
              rescue StandardError => error
                error!("Cannot increase due to #{error.message}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
              end
            end

            # decrease by one
            desc 'Decrease by one quantity'
            route_setting :authentication, optional: true
            route_param :shopoth_line_item_id do
              put '/dec-one' do
                current_cart = Cart.find(params[:id])
                shopoth_line_item = ShopothLineItem.find(params[:shopoth_line_item_id])
                if shopoth_line_item.quantity > 1 && current_cart
                  shopoth_line_item.quantity -= 1
                  shopoth_line_item.discount_amount = shopoth_line_item.variant.consumer_discount_amount * shopoth_line_item.quantity
                  shopoth_line_item.sub_total = (shopoth_line_item.total_price - shopoth_line_item.discount_amount).ceil
                  shopoth_line_item.save!
                  current_cart.update!(current_cart.cart_attributes)
                  present shopoth_line_item, with: Ecommerce::V1::Entities::CartCreation
                else
                  respond_with_json('Must keep one product', HTTP_CODE[:UNPROCESSABLE_ENTITY])
                end
              rescue StandardError => error
                error!("Cannot decrease due to #{error.message}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
              end
            end
          end
        end

        # delete specific cart
        desc 'Delete Cart/Empty Cart'
        route_param :id do
          route_setting :authentication, optional: true
          delete do
            if cart = Cart.find(params[:id])
              cart.destroy_with_shopoth_line_items
              respond_with_json('Successfully deleted', 200)
            else
              respond_with_json('Can not find such cart', 422)
            end
          rescue StandardError => error
            error!("Cannot delete due to #{error.message}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end
        end
      end
    end
  end
end
