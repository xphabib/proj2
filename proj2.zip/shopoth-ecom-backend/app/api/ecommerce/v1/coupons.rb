# frozen_string_literal: true

module Ecommerce
  module V1
    class Coupons < Ecommerce::Base
      helpers Ecommerce::V1::Serializers::CartShowSerializer

      namespace :coupon do
        desc 'Apply coupon'
        params do
          requires :coupon_code, type: String
          requires :cart_id, type: Integer
        end
        put :apply do
          coupon = Coupon.unused.where(usable_type: nil).find_by(code: params[:coupon_code])
          coupon ||= @current_user.coupons.unused.find_by(code: params[:coupon_code])
          unless coupon.present?
            error!(respond_with_json('This coupon is already used or invalid!', HTTP_CODE[:UNPROCESSABLE_ENTITY]),
                   HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end

          cart = Cart.find(params[:cart_id])
          unless cart.check_minimum_cart_value
            error!(respond_with_json('Cart value must be greater or equal to 180tk', HTTP_CODE[:UNPROCESSABLE_ENTITY]),
                   HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end

          cart.user = @current_user unless cart.user
          if coupon.promotion
            promotion = Promotion.active.find(coupon.promotion_id)
            promo_context = Promotions::PromotionCalculation.call(promotion: promotion, cart: cart)
            if promo_context.success?
              discount_amount = promo_context.discount_amount.ceil
              cart.update!(promotion: promotion,
                           cart_discount: discount_amount,
                           coupon_code: params[:coupon_code])
              show_item_in_cart(cart)
            else
              error!(respond_with_json(promo_context.message, HTTP_CODE[:UNPROCESSABLE_ENTITY]),
                     HTTP_CODE[:UNPROCESSABLE_ENTITY])
            end
          else
            voucher_discount = coupon.discount_amount.ceil
            cart.update!(cart_discount: voucher_discount, coupon_code: coupon.code)
            show_item_in_cart(cart)
          end
        rescue StandardError => error
          error!(respond_with_json("Unable to apply coupon due to #{error.full_message}", HTTP_CODE[:UNPROCESSABLE_ENTITY]),
                 HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end
      end
    end
  end
end
