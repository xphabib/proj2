module Ecommerce
  module V1
    class AreaSearch < Ecommerce::Base
      namespace :areas do
        desc 'Get all area based on thana_id'
        params do
          requires :thana_id, type: Integer
          optional :home_delivery, type: Boolean
        end
        route_setting :authentication, optional: true
        get do
          areas = if params[:home_delivery]
                    Area.home_delivery_by_thana(params[:thana_id])
                  else
                    partner_ids = Partner.active.joins(:address).
                                  where(addresses: { thana_id: params[:thana_id] }).ids
                    area_ids = Address.where(addressable_type: 'Partner', addressable_id: partner_ids).
                               pluck(:area_id).uniq
                    Area.where(id: area_ids)
                  end
          present areas, with: Ecommerce::V1::Entities::AreasSearch
        rescue StandardError => error
          error!("Unable to process request #{error}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end
      end
    end
  end
end
