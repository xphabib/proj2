module Ecommerce
  module V1
    class PartnerSearch < Ecommerce::Base
      resource :partners do
        desc 'Get all partners based on area_id'
        params do
          requires :area_id, type: Integer
        end
        route_setting :authentication, optional: true
        get do
          area = Area.find(params[:area_id])
          partners = Partner.find_by_area(area.id) if area.present?
          present partners, with: Ecommerce::V1::Entities::PartnersSearch
        rescue StandardError => error
          error!("Unable to process request #{error}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end
      end
    end
  end
end
