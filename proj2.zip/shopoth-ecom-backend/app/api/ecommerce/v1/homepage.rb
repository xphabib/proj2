# frozen_string_literal: true

class Ecommerce::V1::Homepage < Ecommerce::Base
  helpers Ecommerce::V1::Serializers::HomepageSerializer
  helpers do
    def formatted_trending_response(trending_products)
      @formatted_trending_response ||= trending_products.each_with_object({}) do |(key, products), formatted_trending_products|
        formatted_trending_products[key.to_sentence] = get_homepage_product_list(products)
      end
    end

    def get_available_products(warehouse)
      warehouse.products&.where('warehouse_variants.available_quantity > ?', 0)
    end
  end

  namespace 'homepage' do
    desc 'Get homepage category'
    route_setting :authentication, optional: true
    get '/navigation_categories' do
      menu = menu_category Category.where(parent_id: nil, home_page_visibility: true).order(:position).includes(:sub_categories)
      { category: menu }
    end

    desc 'Get all product sliders'
    params do
      requires :warehouse_id, type: Integer
    end
    route_setting :authentication, optional: true
    get '/product_sliders' do
      warehouse = Warehouse.find(params[:warehouse_id])
      aggregate = {}
      aggregate[:bestselling] =
        get_homepage_product_list Product.get_product_list(Product::PRODUCT_TYPES[:bestselling], warehouse)
      aggregate[:new_arrival] =
        get_homepage_product_list Product.get_product_list(Product::PRODUCT_TYPES[:new_arrival], warehouse)
      aggregate[:trending] =
        formatted_trending_response(Product.get_product_list(Product::PRODUCT_TYPES[:trending], warehouse).group_by { |product| product.categories.map(&:title) })
      aggregate[:daily_deals] = {}
      aggregate[:daily_deals][:result] =
        get_homepage_product_list Product.get_product_list(Product::PRODUCT_TYPES[:daily_deals], warehouse)
      # Daily deals timer
      aggregate[:daily_deals][:starttime] = DateTime.now.in_time_zone('Dhaka')
      aggregate[:daily_deals][:endtime] = 2.days.from_now.in_time_zone('Dhaka')

      aggregate[:private_label] =
        get_homepage_product_list Product.get_product_list(Product::PRODUCT_TYPES[:private_label], warehouse)
      if aggregate[:trending].empty? &&
         aggregate[:new_arrival].empty? &&
         aggregate[:trending].empty? &&
         aggregate[:daily_deals].empty? &&
         aggregate[:private_label].empty?
        respond_with_json 'No product in trending, best selling or new arrival list', HTTP_CODE[:OK]
      else
        aggregate
      end
    end

    desc 'Get homepage slider'
    route_setting :authentication, optional: true
    get '/sliders' do
      aggregate = {}
      aggregate[:slider_image] = to_slider_json Slide.all_slider_images
      aggregate[:banner_image] = to_slider_json Slide.all_banner_images
      aggregate
    end

    desc 'Product search'
    route_setting :authentication, optional: true
    get '/search' do
      warehouse = Warehouse.find(params[:warehouse_id])
      products = get_available_products(warehouse)
      result = {}
      result[:product] = get_product_search_json Product.search_by_title_with_product(params[:q], products)
      result[:brand] = get_product_search_json Product.search_by_brands(params[:q], products)
      result
    end

    desc 'Shop by category'
    route_setting :authentication, optional: true
    get '/shop-by-category' do
      shop_by_category = get_shop_by_category Category.unscoped.where(parent_id: nil, home_page_visibility: true).order(:position)
    end

    desc 'Get all brand'
    route_setting :authentication, optional: true
    get '/all-brands' do
      brands = get_brand_info Brand.all
      { brands: brands }
    end
  end
end
