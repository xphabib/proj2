module Ecommerce
  module V1
    class ReturnCustomerOrders < Ecommerce::Base
      helpers Ecommerce::V1::Serializers::ReturnOrderSerializer

      helpers do
        def check_form_of_return(customer_order, form_of_return)
          if customer_order.pick_up_point? && form_of_return == 'from_home'
            error!(respond_with_json('You are not allowed to return this order from home', HTTP_CODE[:UNPROCESSABLE_ENTITY]),
                   HTTP_CODE[:UNPROCESSABLE_ENTITY])
          elsif (customer_order.home_delivery? || customer_order.express_delivery?) && form_of_return == 'to_partner'
            error!(respond_with_json('You are not allowed to return this order to_partner', HTTP_CODE[:UNPROCESSABLE_ENTITY]),
                   HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end
        end
      end

      resource :return_customer_orders do
        desc 'Get Line Items'
        params do
          requires :customer_order_id, type: Integer
        end
        get do
          customer_order = @current_user.customer_orders.find_by(id: params[:customer_order_id])
          unless customer_order.present? && customer_order.status.completed?
            status :forbidden
            return { success: false, message: 'You are not authorized to see this order or this order is incomplete',
                     status_code: HTTP_CODE[:FORBIDDEN], }
          end
          return_customer_orders = customer_order.return_customer_orders.where.not(return_status: 'initiated')
          requested_return_order = ReturnCustomerOrder.where(customer_order_id: customer_order.id, return_status: 'initiated')
          reasons = ReturnCustomerOrder.reasons
          { reasons: reasons, return_request_details: return_request_details(customer_order),
            returned_items: show_items(return_customer_orders),
            requested_items: show_items(requested_return_order), }
        rescue StandardError => error
          error!("Can not fetch due to #{error.message}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end

        desc 'Get all returned and requested orders'
        get '/lists' do
          return_orders = @current_user.return_customer_orders.order('id DESC')
          return_order_list return_orders
        rescue StandardError => error
          error!("Can not fetch due to #{error.message}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end

        desc 'Get details'
        route_param :id do
          get do
            return_order = @current_user.return_customer_orders.find(params[:id])
            get_details return_order
          rescue StandardError => error
            error!("Can not fetch due to #{error.message}", HTTP_CODE[:UNPROCESSABLE_ENTITY])
          end
        end

        desc 'Request for return order'
        params do
          requires :return_attributes, type: Hash do
            requires :shopoth_line_item_id, type: Integer
            requires :customer_order_id, type: Integer
            requires :reason, type: Integer
            optional :description, type: String
            requires :form_of_return, type: String
            optional :description, type: String
            optional :images_file
            optional :partner_id, type: Integer
          end
          optional :address_attributes, type: Hash do
            requires :district_id, type: Integer
            requires :thana_id, type: Integer
            requires :area_id, type: Integer
            requires :address_line, type: String
            requires :phone, type: String
            optional :alternative_phone, type: String
            optional :zip_code, type: String
          end
        end
        post do
          customer_order = @current_user.customer_orders.with_no_discount.
                           find(params[:return_attributes][:customer_order_id])
          check_form_of_return(customer_order, params[:return_attributes][:form_of_return])
          if customer_order.status.completed? && (customer_order.completed_order_status_date + 7.day) >= Date.today
            params[:return_attributes][:partner_id] = customer_order.partner.present? ? customer_order.partner&.id : nil
            line_item = customer_order.shopoth_line_items.
                        find(params[:return_attributes][:shopoth_line_item_id])

            return_order_count = customer_order.return_customer_orders.
                                 where(shopoth_line_item_id: line_item.id).count
            if return_order_count < line_item.quantity
              return_order = ReturnCustomerOrder.new(params[:return_attributes].
                merge(return_type: 'unpacked',
                      qr_code: line_item.qr_codes[0],
                      warehouse: customer_order.warehouse,
                      return_orderable: @current_user))

              if params[:return_attributes][:form_of_return] == 'from_home'
                return_order.add_address(params[:address_attributes])
              end
              return_order if return_order.save!
            else
              status :unprocessable_entity
              { success: false, message: 'Return request for this line item already exists',
                status_code: HTTP_CODE[:UNPROCESSABLE_ENTITY], }
            end
          else
            respond_with_json('After 7 days, the product cannot be returned', HTTP_CODE[:OK])
          end
        rescue StandardError => error
          error!(respond_with_json('Promotional product can not be returned or invalid order', HTTP_CODE[:UNPROCESSABLE_ENTITY]),
                 HTTP_CODE[:UNPROCESSABLE_ENTITY])
        end
      end
    end
  end
end
