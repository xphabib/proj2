# frozen_string_literal: true

module Ecommerce
  class Base < Grape::API
    # Contains all the constant that will be used for development
    include Ecommerce::V1::Helpers::Constants

    # Helpers to send success or failure message to frontend
    helpers Ecommerce::V1::Helpers::ResponseHelper

    # Helpers to fetch image path
    helpers Ecommerce::V1::Helpers::ImageHelper

    #############################
    # Ecommerce JWT Authentication
    #############################

    before do
      ActiveStorage::Current.host = request.base_url
      auth_optional = route&.settings&.dig(:authentication, :optional)
      if auth_optional
        # allow guest users if the endpoint specifies so
        Rails.logger.info 'Authentication optional for this endpoint'
      else
        error!('401 Unauthorized', 401) unless authenticated!
      end
    end

    helpers do
      def authenticated!
        auth_key = AuthorizationKey.find_by(token: bearer_token)
        if auth_key.present? && !auth_key.is_expired?
          @current_user = auth_key.authable
        end
      rescue StandardError
        false
      end

      def bearer_token
        request.headers.fetch('Authorization', '').split(' ').last
      end
    end

    #
    # Pagination
    #
    include Grape::Kaminari
    PAGINATION_MAX_PER_PAGE = 300
    PAGINATION_DEFAULT_PER_PAGE = 50

    before do
      # grape-kaminari will always return a page header of the given per_page param
      # and not the really used (and maybe enforced) value
      if params[:per_page] && params[:per_page].to_i > PAGINATION_MAX_PER_PAGE
        params[:per_page] = PAGINATION_MAX_PER_PAGE
      end

      # # grape-kaminari will not return a header with the default value of 50 if there was no
      # # per_page param
      # params[:per_page] = PAGINATION_DEFAULT_PER_PAGE unless params[:per_page]
    end

    #############################
    # Versioning and Formatting
    #############################
    version 'v1', using: :path
    format :json
    prefix :api
    formatter :json, Grape::Formatter::Json

    #############################
    # API Mounts with Grape
    #############################
    mount V1::Users
    mount V1::ShopothLineItems
    mount V1::CustomerOrders
    mount V1::Homepage
    mount V1::Carts
    mount V1::Wishlists
    mount V1::Payments
    mount V1::Reviews
    mount V1::UserPreferences
    mount V1::StaticPages
    mount V1::StoreInfos
    mount V1::Footer
    mount V1::SocialLinks
    mount V1::ProductCategory
    mount V1::Brands
    mount V1::ProductView
    mount V1::Otps
    mount V1::Notifications
    mount V1::PickDistrict
    mount V1::ReturnCustomerOrders
    mount V1::ThanaSearch
    mount V1::AreaSearch
    mount V1::PartnerSearch
    mount V1::Coupons
    ###### END of Module Mounting #####
    HTTP_ERROR = [400, 401, 403, 404, 422, 500, 503, 999].freeze
  end
end
